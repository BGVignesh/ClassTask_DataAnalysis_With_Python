import streamlit as ss
import pandas as pd
import numpy as np
import pickle

ss.image(r"https://th.bing.com/th/id/OIP.UBe0bDNpqHjL2MW24h3yywHaBf?rs=1&pid=ImgDetMain")

ss.title("Detecting Brain Tumor")

Area = ss.number_input("Enter Area")
Peri = ss.number_input("Enter Perimeter")
Eq_Dia = ss.number_input("Enter Equivalent Diameter")
Major = ss.number_input("Enter Major Axis")
Minor = ss.number_input("Enter Minor Axis")
Eccen = ss.number_input("Enter Eccentricity")

if ss.button("Submit"):
    feature_list = [Area, Peri,Eq_Dia, Major, Minor, Eccen]
    model = pickle.load(open(r"C:\Users\hi\Projects\Live Projects\Brain Tumor Gaussian Naive Bayes Project\Brain_Tumor_Gaussian_Naive.pkl","rb"))
    result = model.predict([feature_list])

    if result == 0:
        ss.text("No Brain Tumor Detected")
    else:
        ss.text("Brain Tumor Detected")

       	